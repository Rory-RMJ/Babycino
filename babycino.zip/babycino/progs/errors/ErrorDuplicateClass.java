class ErrorDuplicateClass {
    public static void main(String[] args) {
        {
        }
    }
}

class Duplicated {

}

class Duplicated {

}

