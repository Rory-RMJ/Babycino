class Minimal {
    public static void main(String[] args) {
        {
        }
    }
}

class A {
    int x;
    public int f(boolean a, int b) {
        int local1;
        int local2;
        return 0;
    }
}

class B extends A {
    int y;
    public int g() {
        boolean local;
        return 0;
    }
}

