class Subtask4Point2{
    public static void main(String[] args){
        System.out.println(new Point2Test().test(false, false));
    }
}

class Point2Test{
    public int test(boolean firstArgument, boolean secondArgument){
        int result; //stores the result

        //the lhs will be false and the rhs will be true
        if(firstArgument || secondArgument){
            result = 0;
        } else {
            result = 1;
        }
        System.out.println(result);
        return result ;
    }
}
