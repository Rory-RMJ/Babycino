class AndTest {
    public static void main(String[] args){
        if(false && new circuit().test()){
            System.out.println(3);
        } else {

        }
    }
}

class circuit{
    public boolean test(){
        System.out.println(0);
        return true;
    }
}