class SubtaskOne{
    public static void main(String[] args){
        System.out.println(new SubtaskOneTest().test());
    }
}

class SubtaskOneTest {
    public int test(){
        int expressionResult ; //holds the result of the expression. 1 if true, 0 if false

        if (true || false){     //if the result is true, then store 1 in expressionResult
            expressionResult = 1;
        } else { //Else store 0 in expressionResult
            expressionResult = 0 ;
        }
        return expressionResult;
    }
}