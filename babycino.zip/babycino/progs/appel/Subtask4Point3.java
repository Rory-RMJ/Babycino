class Subtask4Point3 {
    public static void main(String[] args){

        if(true || new SubtaskFour().test()){
            System.out.println(1);
        } else{

        }
    }
}

class SubtaskFour{
    public boolean test(){
        //if 0 is printed, then the compiler has not short circuited
        System.out.println(0);
        return false;
    }
}
