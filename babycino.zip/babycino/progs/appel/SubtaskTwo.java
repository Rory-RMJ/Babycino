class SubtaskTwo{
    public static void main(String[] args){
        System.out.println(new SubtaskTwoTest().test(true, 5));
    }
}

class SubtaskTwoTest{
    public int test(boolean boolArg, int intArg){
        boolean resultOne ; //stores the result from the first test
        boolean resultTwo; //stores the result from the second test
        boolean resultThree; //stores the result from the third test

        resultOne = boolArg || intArg;
        resultTwo = intArg || boolArg;
        resultThree = intArg || intArg;

        return 0;
    }
}