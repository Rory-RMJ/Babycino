class Subtask4Point1{
    public static void main(String[] args){
        System.out.println(new Subtask().test(true, true,true,true));
    }
}

class Subtask{
    public int test(boolean firstArg, boolean secondArg, boolean thirdArg, boolean fourthArg){
        boolean result ;//stores the result
        int output;
        //
        //  Using both && and || operators.
        //Compiler will evaluate the && operators before then evaluating the || operator
        //
        result = (firstArg && secondArg) || (thirdArg && fourthArg);

        if(result){
            output = 1;
            System.out.println(output);
        } else {
            output = 0;
            System.out.println(output);
        }
        return output;
    }
}