class SubtaskThree{
    public static void main(String[] args){
        System.out.println(new SubtaskThreeTest().test());
    }
}

class SubtaskThreeTest{
    public int test(){
        int expressionResult; //holds the result of the expression. 1 if true, 0 if false

        if(true || false){  //if the result is true, then store 1 in expressionResult
            expressionResult = 1 ;
        } else {
            expressionResult = 0 ;
        }
        return expressionResult;
    }
}
