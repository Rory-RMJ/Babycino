#!/bin/sh
exec java -cp contrib/antlr/antlr-4.8-complete.jar org.antlr.v4.Tool "$@"

