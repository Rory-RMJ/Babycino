#include <stdio.h>
#include <stdlib.h>

union ilword {
    int n;
    union ilword* ptr;
    void(*f)();
};
typedef union ilword word;

word param[5];
int next_param = 0;

word r0 = {0};

word vg0 = {0};
word vg1 = {0};
word vg2 = {0};
void INIT();
void MAIN();
void Subtask_test();
int main() {
    INIT();
    MAIN();
    return 0;
}

void INIT() {
    word vl[0];
    word r4;
    word r3;
    word r2;
    word r1;
    int p;
    for(p = 0; p <= -1 && p < 5; p++) {
        vl[p] = param[p];
    }
    next_param = 0;
INIT:
    r2.n = 0;
    vg0.ptr = calloc(r2.n, sizeof(word));
    r2.n = 0;
    vg1.ptr = calloc(r2.n, sizeof(word));
    r2.n = 1;
    vg2.ptr = calloc(r2.n, sizeof(word));
    r3 = vg2;
    r4.f = &Subtask_test;
    *(r3.ptr) = r4;
    return;
}

void MAIN() {
    word vl[0];
    word r11;
    word r10;
    word r9;
    word r8;
    word r7;
    word r6;
    word r5;
    word r4;
    word r3;
    word r2;
    word r1;
    int p;
    for(p = 0; p <= -1 && p < 5; p++) {
        vl[p] = param[p];
    }
    next_param = 0;
MAIN:
    r1.n = 1;
    r2.ptr = calloc(r1.n, sizeof(word));
    *(r2.ptr) = vg2;
    r3.n = 1;
    r4.n = 1;
    r5.n = 1;
    r6.n = 1;
    r7 = *(r2.ptr);
    r8.n = 0;
    r9.ptr = r7.ptr + r8.n;
    r10 = *(r9.ptr);
    param[next_param++] = r2;
    param[next_param++] = r3;
    param[next_param++] = r4;
    param[next_param++] = r5;
    param[next_param++] = r6;
    (*(r10.f))();
    r11 = r0;
    printf("%d\n", r11);
    return;
}

void Subtask_test() {
    word vl[7];
    word r3;
    word r2;
    word r1;
    int p;
    for(p = 0; p <= 6 && p < 5; p++) {
        vl[p] = param[p];
    }
    next_param = 0;
Subtask_test:
    r1 = vl[1];
    if (r1.n == 0) goto Subtask_test_0;
    r1 = vl[2];
Subtask_test_0:
    r2 = vl[3];
    if (r2.n == 0) goto Subtask_test_1;
    r2 = vl[4];
Subtask_test_1:
    r3.n = r1.n  r2.n;
    vl[5] = r3;
    if (vl[5].n == 0) goto Subtask_test_2;
    vl[6].n = 1;
    printf("%d\n", vl[6]);
    goto Subtask_test_3;
Subtask_test_2:
    vl[6].n = 0;
    printf("%d\n", vl[6]);
Subtask_test_3:
    r0 = vl[6];
    return;
}

